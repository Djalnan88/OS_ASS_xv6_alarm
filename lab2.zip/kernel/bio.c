// Buffer cache.
//
// The buffer cache is a linked list of buf structures holding
// cached copies of disk block contents.  Caching disk blocks
// in memory reduces the number of disk reads and also provides
// a synchronization point for disk blocks used by multiple processes.
//
// Interface:
// * To get a buffer for a particular disk block, call bread.
// * After changing buffer data, call bwrite to write it to disk.
// * When done with the buffer, call brelse.
// * Do not use the buffer after calling brelse.
// * Only one process at a time can use a buffer,
//     so do not keep them longer than necessary.


#include "types.h"
#include "param.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "riscv.h"
#include "defs.h"
#include "fs.h"
#include "buf.h"

struct buf buf[NBUF];

struct bcache_bucket {
  struct spinlock lock;
  struct buf head;
};

struct {
  struct bcache_bucket bucket[NBUCKETS];
} bcache;

void
binit(void)
{
  struct buf *b;
  char lock_name[10];

  for(int i = 0; i < NBUCKETS; i++) {
    snprintf(lock_name, sizeof(lock_name), "bcache%d", i);
    initlock(&bcache.bucket[i].lock, lock_name);

    bcache.bucket[i].head.prev = &bcache.bucket[i].head;
    bcache.bucket[i].head.next = &bcache.bucket[i].head;
  }

  // Create linked list of buffers
  for(b = buf; b < buf+NBUF; b++){
    int i = (b - buf) % NBUCKETS;

    initsleeplock(&b->lock, "buffer");

    b->next = bcache.bucket[i].head.next;
    b->prev = &bcache.bucket[i].head;
    bcache.bucket[i].head.next->prev = b;
    bcache.bucket[i].head.next = b; 
  }
}

static int hash(uint blockno){return blockno%NBUCKETS;}

// Look through buffer cache for block on device dev.
// If not found, allocate a buffer.
// In either case, return locked buffer.
static struct buf*
bget(uint dev, uint blockno)
{
  struct buf *b;
  int i = hash(blockno);
  struct bcache_bucket *bucket = &bcache.bucket[i];

  acquire(&bucket->lock);

  // Is the block already cached?
  for(b = bucket->head.next; b != &bucket->head; b = b->next){
    if(b->dev == dev && b->blockno == blockno){
      b->refcnt++;
      release(&bucket->lock);
      acquiresleep(&b->lock);
      return b;
    }
  }

  for (b = bucket->head.prev; b != &bucket->head; b = b->prev) {
    if (b->refcnt == 0) {
      b->dev = dev;
      b->blockno = blockno;
      b->valid = 0;
      b->refcnt = 1;

      release(&bucket->lock);
      acquiresleep(&b->lock);
      return b;
    }
  }
  release(&bucket->lock);

  for(int j = 0; j < NBUCKETS; j++) {
    struct bcache_bucket *other_bucket = &bcache.bucket[j];

    acquire(&other_bucket->lock);

    for(b = other_bucket->head.next; b != &other_bucket->head; b = b->next) {
      if(b->refcnt == 0) {
        b->next->prev = b->prev;
        b->prev->next = b->next;

        acquire(&bucket->lock);

        b->dev = dev;
        b->blockno = blockno;
        b->valid = 0;
        b->refcnt = 1;

        b->next = bucket->head.next;
        b->prev = &bucket->head;
        bucket->head.next->prev = b;
        bucket->head.next = b;

        release(&bucket->lock);
        release(&other_bucket->lock);

        acquiresleep(&b->lock);
        return b;
      }
    }
    release(&other_bucket->lock);
  }
  panic("bget: no buffers");
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
  if(!holdingsleep(&b->lock))
    panic("bwrite");
  virtio_disk_rw(b, 1);
}

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
  if(!holdingsleep(&b->lock))
    panic("brelse");

  releasesleep(&b->lock);

  int i = hash(b->blockno);
  struct bcache_bucket *bucket = &bcache.bucket[i];
  acquire(&bucket->lock);

  b->refcnt--;
  if (b->refcnt == 0) {
    // no one is waiting for it.
    b->next->prev = b->prev;
    b->prev->next = b->next;
    b->next = bucket->head.next;
    b->prev = &bucket->head;
    bucket->head.next->prev = b;
    bucket->head.next = b;
  }
  
  release(&bucket->lock);
}

void
bpin(struct buf *b) {
  int i = hash(b->blockno);
  struct bcache_bucket *bucket = &bcache.bucket[i];

  acquire(&bucket->lock);
  b->refcnt++;
  release(&bucket->lock);
}

void
bunpin(struct buf *b) {
  int i = hash(b->blockno);
  struct bcache_bucket *bucket = &bcache.bucket[i];

  acquire(&bucket->lock);
  b->refcnt--;
  release(&bucket->lock);
}


